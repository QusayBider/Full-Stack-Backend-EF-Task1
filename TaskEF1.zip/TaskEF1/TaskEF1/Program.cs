﻿using TaskEF1.Data;
using TaskEF1.Models;

namespace TaskEF1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            ApplicationDbContext context= new ApplicationDbContext();
            var user = new User
            {
                Name = "Qusay Bider ",
                Email = "QusayBider@gmail.com",
                Password = "Qusay1234"
            };

            var blogs = new List<Blog>
             {
            new Blog { Title = "Blog 1", Description = "Description 1", User = user },
            new Blog { Title = "Blog 2", Description = "Description 2", User = user },
            new Blog { Title = "Blog 3", Description = "Description 3", User = user },
            new Blog { Title = "Blog 4", Description = "Description 4", User = user },
            new Blog { Title = "Blog 5", Description = "Description 5", User = user }
            };
            context.Users.Add(user);
            context.Blogs.AddRange(blogs);
            context.SaveChanges();
        }
    }
}
